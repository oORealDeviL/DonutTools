package com.donuttools.client;

import java.text.NumberFormat;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ProfitTracker {
    private ProfitTracker() {}

    /*
     * We intentionally only inspect messages received after start().
     * This means enabling the tracker does NOT backfill old chat.
     *
     * Supported examples:
     *   You earned $840 from auction
     *   You earned $2,301.50 from auction
     *   Sold item for $840
     *   Sale: $840
     *   Received $840 for ...
     */
    private static final Pattern MONEY = Pattern.compile(
            "(?i)(?:\\$\\s*|USD\\s*)([0-9][0-9,]*(?:\\.[0-9]{1,2})?)"
    );

    private static final Pattern SALE_CONTEXT = Pattern.compile(
            "(?i)\\b(earned|earn|sold|sale|sales|sold\\s+for|received|receive|revenue|auction|"
                    + "selling|sell|payment|paid|profit|you\\s+made|made)\\b"
    );

    private static boolean running;
    private static long totalCents;
    private static long lastSaleCents;
    private static long sales;
    private static long startedAt;

    private static String lastMessageKey = "";
    private static long lastMessageAt;
    private static final Deque<Long> history = new ArrayDeque<>();

    public static void start() {
        running = true;
        startedAt = System.currentTimeMillis();
        lastMessageKey = "";
        lastMessageAt = 0L;
        // Do not clear totals here: START/STOP is a pause switch.
        // RESET is the explicit way to start a new profit session.
    }

    public static void stop() {
        running = false;
    }

    public static void reset() {
        running = false;
        totalCents = 0;
        lastSaleCents = 0;
        sales = 0;
        startedAt = 0;
        lastMessageKey = "";
        lastMessageAt = 0L;
        history.clear();
    }

    public static boolean isRunning() {
        return running;
    }

    public static long getSales() {
        return sales;
    }

    public static long getTotalCents() {
        return totalCents;
    }

    public static long getLastSaleCents() {
        return lastSaleCents;
    }

    public static long getElapsedSeconds() {
        if (!running || startedAt == 0) return 0;
        return Math.max(0, (System.currentTimeMillis() - startedAt) / 1000L);
    }

    public static Deque<Long> history() {
        return new ArrayDeque<>(history);
    }

    public static boolean processMessage(String raw) {
        if (!running || raw == null || raw.isBlank()) return false;

        String clean = raw.replaceAll("\\s+", " ").trim();
        long now = System.currentTimeMillis();

        // CHAT and GAME can both deliver the same line. Prevent a double count.
        String key = clean.toLowerCase(Locale.ROOT);
        if (key.equals(lastMessageKey) && now - lastMessageAt < 750L) {
            return false;
        }

        Matcher money = MONEY.matcher(clean);
        if (!money.find()) return false;

        // A money value alone is not enough: "$840" in a balance/status line
        // must not automatically become a sale.
        if (!SALE_CONTEXT.matcher(clean).find()) return false;

        String normalized = money.group(1).replace(",", "");
        try {
            double amount = Double.parseDouble(normalized);
            long cents = Math.round(amount * 100.0);
            if (cents <= 0) return false;

            lastMessageKey = key;
            lastMessageAt = now;
            recordSale(cents);
            return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    public static void recordSale(long cents) {
        if (cents <= 0) return;
        lastSaleCents = cents;
        totalCents += cents;
        sales++;
        history.addFirst(cents);
        while (history.size() > 20) history.removeLast();
    }

    public static String money(long cents) {
        double value = cents / 100.0;
        return NumberFormat.getNumberInstance(Locale.US).format(value) + " USD";
    }

    public static String compactMoney(long cents) {
        double value = cents / 100.0;
        if (Math.abs(value) >= 1_000_000_000) return String.format(Locale.US, "$%.2fB", value / 1_000_000_000);
        if (Math.abs(value) >= 1_000_000) return String.format(Locale.US, "$%.2fM", value / 1_000_000);
        if (Math.abs(value) >= 1_000) return String.format(Locale.US, "$%.2fK", value / 1_000);
        return String.format(Locale.US, "$%,.2f", value);
    }
}
