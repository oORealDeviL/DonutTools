package com.donuttools.client.util;

import java.util.Locale;

public final class CalculatorState {
    private CalculatorState() {}

    public static String expression = "";
    public static String result = "0";

    public static void clear() {
        expression = "";
        result = "0";
    }

    public static void backspace() {
        if (!expression.isEmpty()) expression = expression.substring(0, expression.length() - 1);
    }

    public static void append(String value) {
        if (value != null && !value.isEmpty()) expression += value;
    }

    public static void evaluate() {
        if (expression.isBlank()) return;
        try {
            double value = new Parser(expression).parse();
            if (!Double.isFinite(value)) {
                result = "Error";
                return;
            }
            if (Math.rint(value) == value) {
                result = String.format(Locale.US, "%.0f", value);
            } else {
                result = String.format(Locale.US, "%.8f", value)
                        .replaceAll("0+$", "")
                        .replaceAll("\\.$", "");
            }
        } catch (RuntimeException e) {
            result = "Error";
        }
    }

    private static final class Parser {
        private final String s;
        private int pos;

        Parser(String s) {
            this.s = s.replace(",", "").replace(" ", "");
        }

        double parse() {
            double v = expression();
            if (pos != s.length()) throw new IllegalArgumentException();
            return v;
        }

        double expression() {
            double v = term();
            while (pos < s.length()) {
                char c = s.charAt(pos);
                if (c == '+') { pos++; v += term(); }
                else if (c == '-') { pos++; v -= term(); }
                else break;
            }
            return v;
        }

        double term() {
            double v = factor();
            while (pos < s.length()) {
                char c = s.charAt(pos);
                if (c == '*') { pos++; v *= factor(); }
                else if (c == '/') { pos++; v /= factor(); }
                else break;
            }
            return v;
        }

        double factor() {
            if (pos < s.length() && s.charAt(pos) == '+') { pos++; return factor(); }
            if (pos < s.length() && s.charAt(pos) == '-') { pos++; return -factor(); }
            if (pos < s.length() && s.charAt(pos) == '(') {
                pos++;
                double v = expression();
                if (pos >= s.length() || s.charAt(pos) != ')') throw new IllegalArgumentException();
                pos++;
                return v;
            }
            int start = pos;
            while (pos < s.length() && (Character.isDigit(s.charAt(pos)) || s.charAt(pos) == '.')) pos++;
            if (start == pos) throw new IllegalArgumentException();
            return Double.parseDouble(s.substring(start, pos));
        }
    }
}
