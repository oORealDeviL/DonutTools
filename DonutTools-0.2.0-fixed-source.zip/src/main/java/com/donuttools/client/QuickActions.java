package com.donuttools.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

public final class QuickActions {
    private QuickActions() {}

    public static final int COUNT = 4;
    private static final String[] defaultNames = {"10% TAX", "×2", "÷2", "STACK"};
    private static final String[] defaultExpressions = {"*0.90", "*2", "/2", "*64"};

    private static final String[] names = Arrays.copyOf(defaultNames, COUNT);
    private static final String[] expressions = Arrays.copyOf(defaultExpressions, COUNT);

    private static Path file() {
        return net.fabricmc.loader.api.FabricLoader.getInstance()
                .getConfigDir().resolve("donuttools-quick-actions.json");
    }

    public static void load() {
        Path path = file();
        if (!Files.exists(path)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(path)).getAsJsonObject();
            JsonArray actions = root.getAsJsonArray("actions");
            if (actions == null) return;
            for (int i = 0; i < COUNT && i < actions.size(); i++) {
                JsonObject a = actions.get(i).getAsJsonObject();
                if (a.has("name")) names[i] = a.get("name").getAsString();
                if (a.has("expression")) expressions[i] = a.get("expression").getAsString();
            }
        } catch (Exception ignored) {
            // Bad config should never prevent the mod from loading.
        }
    }

    public static void save() {
        JsonObject root = new JsonObject();
        JsonArray actions = new JsonArray();
        for (int i = 0; i < COUNT; i++) {
            JsonObject a = new JsonObject();
            a.addProperty("name", names[i]);
            a.addProperty("expression", expressions[i]);
            actions.add(a);
        }
        root.add("actions", actions);
        try {
            Files.writeString(file(), root.toString());
        } catch (IOException ignored) {}
    }

    public static String name(int index) { return names[index]; }
    public static String expression(int index) { return expressions[index]; }

    public static void set(int index, String name, String expression) {
        if (index < 0 || index >= COUNT) return;
        names[index] = name == null || name.isBlank() ? "ACTION " + (index + 1) : name;
        expressions[index] = expression == null ? "" : expression;
        save();
    }

    public static void apply(int index) {
        if (index < 0 || index >= COUNT) return;
        String expr = expressions[index];
        if (expr.isBlank()) return;
        CalculatorState.append(expr);
        CalculatorState.evaluate();
    }

    private static final class CalculatorState {
        private static final com.donuttools.client.util.CalculatorState STATE = null;
        static void append(String value) {
            com.donuttools.client.util.CalculatorState.append(value);
        }
        static void evaluate() {
            com.donuttools.client.util.CalculatorState.evaluate();
        }
    }
}
