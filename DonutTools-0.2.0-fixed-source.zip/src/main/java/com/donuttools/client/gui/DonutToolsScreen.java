package com.donuttools.client.gui;

import com.donuttools.client.ProfitTracker;
import com.donuttools.client.QuickActions;
import com.donuttools.client.util.CalculatorState;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class DonutToolsScreen extends Screen {
    private enum Page { CALCULATOR, PROFIT, QUICK_ACTIONS }

    private final Screen parent;
    private final Page page;

    private int panelX, panelY, panelW, panelH;

    private DonutToolsScreen(Screen parent, Page page) {
        super(Component.literal("Donut Tools"));
        this.parent = parent;
        this.page = page;
    }

    public static DonutToolsScreen calculator(Screen parent) { return new DonutToolsScreen(parent, Page.CALCULATOR); }
    public static DonutToolsScreen profit(Screen parent) { return new DonutToolsScreen(parent, Page.PROFIT); }
    public static DonutToolsScreen quickActions(Screen parent) { return new DonutToolsScreen(parent, Page.QUICK_ACTIONS); }

    @Override
    protected void init() {
        clearWidgets();
        panelW = Math.min(900, width - 40);
        panelH = Math.min(620, height - 70);
        panelX = (width - panelW) / 2;
        panelY = Math.max(30, (height - panelH) / 2);

        if (page == Page.CALCULATOR) initCalculator();
        else if (page == Page.PROFIT) initProfit();
        else initQuickActions();

        addButton(panelX + 24, panelY + panelH - 48, 100, 28, "BACK", b -> onClose());
    }

    private void initCalculator() {
        int keypadX = panelX + 28;
        int keypadY = panelY + 205;
        int bw = 72, bh = 42, gap = 8;

        String[][] keys = {
                {"7","8","9","÷"},
                {"4","5","6","×"},
                {"1","2","3","−"},
                {"0",".","(",")"},
                {"C","⌫","%","="}
        };

        for (int r = 0; r < keys.length; r++) {
            for (int c = 0; c < keys[r].length; c++) {
                String key = keys[r][c];
                addButton(keypadX + c * (bw + gap), keypadY + r * (bh + gap),
                        bw, bh, key, b -> calculatorKey(key));
            }
        }

        int ax = panelX + 385;
        addButton(ax, keypadY, 200, 36, "EDIT QUICK ACTIONS", b -> minecraft.setScreen(quickActions(this)));

        for (int i = 0; i < QuickActions.COUNT; i++) {
            int index = i;
            addButton(ax, keypadY + 48 + i * 48, 200, 38,
                    QuickActions.name(i), b -> QuickActions.apply(index));
        }
    }

    private void calculatorKey(String key) {
        switch (key) {
            case "C" -> CalculatorState.clear();
            case "⌫" -> CalculatorState.backspace();
            case "=" -> CalculatorState.evaluate();
            case "÷" -> CalculatorState.append("/");
            case "×" -> CalculatorState.append("*");
            case "−" -> CalculatorState.append("-");
            case "%" -> CalculatorState.append("/100");
            default -> CalculatorState.append(key);
        }
    }

    private void initProfit() {
        addButton(panelX + panelW - 240, panelY + 62, 100, 38,
                ProfitTracker.isRunning() ? "ON" : "OFF", b -> {
                    if (ProfitTracker.isRunning()) ProfitTracker.stop();
                    else ProfitTracker.start();
                    rebuildWidgets();
                });

        addButton(panelX + panelW - 130, panelY + 62, 100, 38, "RESET", b -> {
            ProfitTracker.reset();
            rebuildWidgets();
        });
    }

    private void initQuickActions() {
        for (int i = 0; i < QuickActions.COUNT; i++) {
            int row = i;
            int yy = panelY + 92 + i * 72;

            EditBox name = new EditBox(font, panelX + 40, yy, 190, 32, Component.literal("Name"));
            name.setValue(QuickActions.name(i));
            addRenderableWidget(name);

            EditBox expression = new EditBox(font, panelX + 245, yy, 320, 32, Component.literal("Expression"));
            expression.setValue(QuickActions.expression(i));
            addRenderableWidget(expression);

            addButton(panelX + 585, yy, 100, 32, "SAVE", b ->
                    QuickActions.set(row, name.getValue(), expression.getValue()));
        }
    }

    private void addButton(int x, int y, int w, int h, String label, Button.OnPress action) {
        addRenderableWidget(Button.builder(Component.literal(label), action).bounds(x, y, w, h).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        // Draw first, then let vanilla widgets render on top.
        g.fill(0, 0, width, height, 0xFF070A10);

        // Technical background grid — deliberately subtle.
        for (int xx = 0; xx < width; xx += 48) g.fill(xx, 0, xx + 1, height, 0x0C4A6678);
        for (int yy = 0; yy < height; yy += 48) g.fill(0, yy, width, yy + 1, 0x0C4A6678);

        // Main panel.
        g.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xFF101722);
        g.fill(panelX, panelY, panelX + panelW, panelY + 3, 0xFF45C9FF);

        g.text(font, "DONUT TOOLS", panelX + 24, panelY + 20, 0xFFFFFFFF, true);
        g.text(font, title(), panelX + 24, panelY + 42, 0xFF7F8EA3, false);

        if (page == Page.CALCULATOR) renderCalculator(g);
        else if (page == Page.PROFIT) renderProfit(g);
        else renderQuickActions(g);

        super.extractRenderState(g, mouseX, mouseY, delta);
    }

    private String title() {
        return switch (page) {
            case CALCULATOR -> "CALCULATOR  •  KEYBIND O";
            case PROFIT -> "PROFIT TRACKER  •  KEYBIND P";
            case QUICK_ACTIONS -> "QUICK ACTIONS";
        };
    }

    private void renderCalculator(GuiGraphicsExtractor g) {
        int ex = panelX + 28, ey = panelY + 72, ew = panelW - 56;
        g.fill(ex, ey, ex + ew, ey + 104, 0xFF151F2B);
        g.fill(ex, ey, ex + 3, ey + 104, 0xFF45C9FF);

        g.text(font, "EXPRESSION", ex + 18, ey + 18, 0xFF7F8EA3, false);
        String expression = CalculatorState.expression.isBlank() ? "0" : CalculatorState.expression;
        g.text(font, expression, ex + 18, ey + 43, 0xFFFFFFFF, true);
        g.text(font, CalculatorState.result, ex + ew - 180, ey + 72, 0xFF45C9FF, true);

        g.text(font, "QUICK ACTIONS", panelX + 385, panelY + 180, 0xFFFFFFFF, true);
        g.text(font, "Editable names + expressions", panelX + 385, panelY + 197, 0xFF7F8EA3, false);
        g.text(font, "Example: 10% TAX  →  *0.90", panelX + 385, panelY + 408, 0xFF64748B, false);
    }

    private void renderProfit(GuiGraphicsExtractor g) {
        boolean running = ProfitTracker.isRunning();

        g.text(font, running ? "● LISTENING" : "● OFF",
                panelX + 30, panelY + 82,
                running ? 0xFF49E58A : 0xFFFF657A, true);

        drawMetric(g, panelX + 30, panelY + 116, 250, "TOTAL PROFIT",
                ProfitTracker.compactMoney(ProfitTracker.getTotalCents()));
        drawMetric(g, panelX + 295, panelY + 116, 150, "SALES",
                String.valueOf(ProfitTracker.getSales()));
        drawMetric(g, panelX + 460, panelY + 116, 220, "LAST SALE",
                ProfitTracker.compactMoney(ProfitTracker.getLastSaleCents()));

        g.text(font, "NEW SALES FROM CHAT", panelX + 30, panelY + 224, 0xFFFFFFFF, true);
        g.text(font, running
                ? "Only messages received after ON are considered."
                : "OFF = chat is ignored. No old messages are scanned.",
                panelX + 30, panelY + 244, 0xFF7F8EA3, false);

        int yy = panelY + 272;
        int i = 1;
        for (Long sale : ProfitTracker.history()) {
            g.fill(panelX + 30, yy, panelX + panelW - 30, yy + 32, 0xFF151F2B);
            g.text(font, "#" + i++, panelX + 44, yy + 9, 0xFF66758A, false);
            g.text(font, ProfitTracker.money(sale), panelX + 92, yy + 9, 0xFFDDE7F3, true);
            yy += 38;
            if (yy > panelY + panelH - 72) break;
        }

        if (ProfitTracker.getSales() == 0) {
            g.text(font, running ? "Waiting for a new sale message..." : "Turn ON to start listening.",
                    panelX + 30, yy + 8, 0xFF7F8EA3, false);
        }

        g.text(font, "Detects sale messages containing a USD amount, e.g.  You earned $840 from auction",
                panelX + 30, panelY + panelH - 72, 0xFF64748B, false);
    }

    private void renderQuickActions(GuiGraphicsExtractor g) {
        g.text(font, "Set the button label and the math expression it applies.", panelX + 40, panelY + 68,
                0xFF7F8EA3, false);
        g.text(font, "Examples: *0.90   *64   /64   +500", panelX + 40, panelY + 82,
                0xFF45C9FF, false);
        g.text(font, "NAME", panelX + 40, panelY + 108, 0xFF64748B, false);
        g.text(font, "EXPRESSION", panelX + 245, panelY + 108, 0xFF64748B, false);
    }

    private void drawMetric(GuiGraphicsExtractor g, int x, int y, int w, String label, String value) {
        g.fill(x, y, x + w, y + 78, 0xFF151F2B);
        g.fill(x, y, x + 3, y + 78, 0xFF45C9FF);
        g.text(font, label, x + 16, y + 14, 0xFF7F8EA3, false);
        g.text(font, value, x + 16, y + 39, 0xFFFFFFFF, true);
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        int key = event.key();
        if (page == Page.CALCULATOR) {
            if (key == 259) { CalculatorState.backspace(); return true; }
            if (key == 257 || key == 335) { CalculatorState.evaluate(); return true; }
        }
        if (key == 256) { onClose(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
