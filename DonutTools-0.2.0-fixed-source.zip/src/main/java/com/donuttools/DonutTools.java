package com.donuttools;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class DonutTools implements ModInitializer {
    public static final String MOD_ID = "donuttools";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Donut Tools 0.2.0 initialized.");
    }
}
