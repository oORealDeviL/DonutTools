# Donut Tools 0.2.0

Fabric client mod for Minecraft 26.1.2 / Java 25.

## Two independent keybinds

- `O` → Calculator
- `P` → Profit Tracker

They are separate screens and can be rebound from Minecraft's Controls menu.

## Calculator

- Real working keyboard calculator.
- 7/8/9 … operators, brackets, percent, clear and backspace.
- Four Quick Actions are editable from **EDIT QUICK ACTIONS**.
- Each action has a custom label and expression, stored in:
  `.minecraft/config/donuttools-quick-actions.json`

Examples:
- `10% TAX` → `*0.90`
- `STACK` → `*64`
- `PER ITEM` → `/64`

## Profit Tracker

The tracker is intentionally simple:

- `ON/OFF`
- `RESET`
- Total Profit
- Sale count
- Last Sale
- List of detected sale amounts

When switched **ON**, it starts listening at that moment. Old chat is never backfilled.

It checks incoming Minecraft chat/game messages for sale context plus a USD amount, including:

- `You earned $840 from auction`
- `You earned $2,301.50 from auction`
- `Sold for $840`
- `Sale: $840`
- `Received $840`

The CHAT and GAME callbacks are deduplicated so the same server message is not counted twice.

## Build

Minecraft 26.1.x requires Java 25.

Run locally with Gradle 9.4+:

    gradle build

Or push the project to GitHub and run **Actions → Build DonutTools → Run workflow**.
The workflow uses Java 25 and uploads `DonutTools-JAR`.
