# Donut Tools 0.2.0

Fabric client mod for Minecraft 26.1.2.

## Features

- Calculator on `O`
- Profit Tracker on `P`
- Profit Tracker has only ON/OFF + RESET and a live sale list.
- When Profit Tracker is OFF, chat is ignored.
- When turned ON, only new incoming messages are considered; old chat is never backfilled.
- Detects sale-style messages such as:
  - `You earned $840 from auction`
  - `Sold for $840`
  - `Sale: $840`
- GAME + CHAT callbacks are deduplicated so the same line is not counted twice.
- Calculator has 4 user-editable Quick Actions.
- Quick Actions are stored in `.minecraft/config/donuttools-quick-actions.json`.

## Build

Minecraft 26.1.x uses Java 25. The project uses Fabric Loom 1.15.5 and Gradle 9.4.0.
Run:

    gradle build

The GitHub Actions workflow does the same on Ubuntu with Java 25.
