package com.donuttools.client.gui;

import com.donuttools.client.ProfitTracker;
import com.donuttools.client.QuickActions;
import com.donuttools.client.util.CalculatorState;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class DonutToolsScreen extends Screen {
    private enum Page { CALCULATOR, PROFIT, QUICK_ACTIONS }

    private final Screen parent;
    private final Page page;

    private DonutToolsScreen(Screen parent, Page page) {
        super(Component.literal("Donut Tools"));
        this.parent = parent;
        this.page = page;
    }

    public static DonutToolsScreen calculator(Screen parent) {
        return new DonutToolsScreen(parent, Page.CALCULATOR);
    }

    public static DonutToolsScreen profit(Screen parent) {
        return new DonutToolsScreen(parent, Page.PROFIT);
    }

    public static DonutToolsScreen quickActions(Screen parent) {
        return new DonutToolsScreen(parent, Page.QUICK_ACTIONS);
    }

    @Override
    protected void init() {
        clearWidgets();
        int panelW = Math.min(820, width - 50);
        int x = (width - panelW) / 2;
        int y = 54;

        if (page == Page.CALCULATOR) buildCalculator(x, y, panelW);
        if (page == Page.PROFIT) buildProfit(x, y, panelW);
        if (page == Page.QUICK_ACTIONS) buildQuickActions(x, y, panelW);

        addButton(x, height - 42, 100, 28, "BACK", b -> onClose());
    }

    private void buildCalculator(int x, int y, int w) {
        String[][] keys = {
                {"7","8","9","÷"},
                {"4","5","6","×"},
                {"1","2","3","−"},
                {"0",".","(",")"},
                {"C","⌫","%","="}
        };

        int bw = 72, bh = 34, gap = 7;
        int startX = x + 28;
        int startY = y + 142;

        for (int r = 0; r < keys.length; r++) {
            for (int c = 0; c < keys[r].length; c++) {
                String key = keys[r][c];
                int bx = startX + c * (bw + gap);
                int by = startY + r * (bh + gap);
                addButton(bx, by, bw, bh, key, b -> calculatorKey(key));
            }
        }

        int actionX = x + 385;
        addButton(actionX, startY, 150, 34, "EDIT ACTIONS", b ->
                minecraft.setScreen(quickActions(this)));

        for (int i = 0; i < QuickActions.COUNT; i++) {
            int index = i;
            addButton(actionX, startY + 44 + i * 44, 150, 34, QuickActions.name(i),
                    b -> QuickActions.apply(index));
        }
    }

    private void calculatorKey(String key) {
        switch (key) {
            case "C" -> CalculatorState.clear();
            case "⌫" -> CalculatorState.backspace();
            case "=" -> CalculatorState.evaluate();
            case "÷" -> CalculatorState.append("/");
            case "×" -> CalculatorState.append("*");
            case "−" -> CalculatorState.append("-");
            case "%" -> CalculatorState.append("/100");
            default -> CalculatorState.append(key);
        }
    }

    private void buildProfit(int x, int y, int w) {
        // Deliberately only ON/OFF + RESET. No item list, no item metadata.
        addButton(x + w - 235, y + 42, 100, 34,
                ProfitTracker.isRunning() ? "ON" : "OFF", b -> {
                    if (ProfitTracker.isRunning()) ProfitTracker.stop();
                    else ProfitTracker.start();
                    rebuildWidgets();
                });

        addButton(x + w - 125, y + 42, 90, 34, "RESET", b -> {
            ProfitTracker.reset();
            rebuildWidgets();
        });
    }

    private void buildQuickActions(int x, int y, int w) {
        for (int i = 0; i < QuickActions.COUNT; i++) {
            int row = i;
            int yy = y + 64 + i * 62;
            EditBox name = new EditBox(font, x + 30, yy, 190, 28, Component.literal("Name"));
            name.setValue(QuickActions.name(i));
            addRenderableWidget(name);

            EditBox expression = new EditBox(font, x + 235, yy, 270, 28, Component.literal("Expression"));
            expression.setValue(QuickActions.expression(i));
            addRenderableWidget(expression);

            addButton(x + 520, yy, 100, 28, "SAVE", b ->
                    QuickActions.set(row, name.getValue(), expression.getValue()));
        }
    }

    private void addButton(int x, int y, int w, int h, String label, Button.OnPress action) {
        addRenderableWidget(Button.builder(Component.literal(label), action).bounds(x, y, w, h).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);

        g.fill(0, 0, width, height, 0xFF070B12);
        drawGrid(g);

        int panelW = Math.min(820, width - 50);
        int x = (width - panelW) / 2;
        int y = 54;

        g.fill(x, y, x + panelW, height - 54, 0xFF101824);
        g.fill(x, y, x + panelW, y + 3, 0xFF45C9FF);

        g.text(font, "DONUT TOOLS", x + 28, 18, 0xFFFFFFFF, true);
        g.text(font, title(), x + 28, 37, 0xFF8190A4, false);

        if (page == Page.CALCULATOR) renderCalculator(g, x, y, panelW);
        if (page == Page.PROFIT) renderProfit(g, x, y, panelW);
        if (page == Page.QUICK_ACTIONS) renderQuickActions(g, x, y, panelW);
    }

    private String title() {
        return switch (page) {
            case CALCULATOR -> "CALCULATOR  [O]";
            case PROFIT -> "PROFIT TRACKER  [P]";
            case QUICK_ACTIONS -> "QUICK ACTIONS";
        };
    }

    private void renderCalculator(GuiGraphicsExtractor g, int x, int y, int w) {
        g.fill(x + 28, y + 24, x + 355, y + 108, 0xFF151F2B);
        g.text(font, "EXPRESSION", x + 42, y + 40, 0xFF7F8EA3, false);
        g.text(font, CalculatorState.expression.isBlank() ? "0" : CalculatorState.expression,
                x + 42, y + 65, 0xFFFFFFFF, true);
        g.text(font, CalculatorState.result, x + 42, y + 88, 0xFF45C9FF, true);

        g.text(font, "QUICK ACTIONS", x + 385, y + 124, 0xFFFFFFFF, true);
        g.text(font, "Edit the label + expression yourself.", x + 385, y + 142, 0xFF7F8EA3, false);
    }

    private void renderProfit(GuiGraphicsExtractor g, int x, int y, int w) {
        boolean running = ProfitTracker.isRunning();
        g.text(font, running ? "● LISTENING" : "● OFF", x + 30, y + 38,
                running ? 0xFF49E58A : 0xFFFF657A, true);

        drawMetric(g, x + 30, y + 72, 220, "TOTAL PROFIT",
                ProfitTracker.compactMoney(ProfitTracker.getTotalCents()));
        drawMetric(g, x + 265, y + 72, 160, "SALES",
                String.valueOf(ProfitTracker.getSales()));
        drawMetric(g, x + 440, y + 72, 190, "LAST SALE",
                ProfitTracker.compactMoney(ProfitTracker.getLastSaleCents()));

        g.text(font, "LIVE CHAT SALES", x + 30, y + 190, 0xFFFFFFFF, true);

        int yy = y + 214;
        int i = 1;
        for (Long sale : ProfitTracker.history()) {
            g.fill(x + 30, yy - 3, x + 630, yy + 25, 0xFF151F2B);
            g.text(font, "#" + i++, x + 42, yy + 6, 0xFF6F7E91, false);
            g.text(font, ProfitTracker.money(sale), x + 82, yy + 6, 0xFFDDE7F3, false);
            yy += 31;
            if (yy > height - 82) break;
        }

        if (ProfitTracker.getSales() == 0) {
            g.text(font, running
                    ? "Waiting for new chat messages containing a sale amount..."
                    : "Turn ON to start listening. Old chat is never backfilled.",
                    x + 30, yy + 8, 0xFF7F8EA3, false);
        }

        g.text(font, "Examples detected:  You earned $840 from auction  •  Sold for $840  •  Sale: $840",
                x + 30, height - 72, 0xFF64748B, false);
    }

    private void renderQuickActions(GuiGraphicsExtractor g, int x, int y, int w) {
        g.text(font, "Set any label and expression, then press SAVE.", x + 30, y + 28,
                0xFF7F8EA3, false);
        g.text(font, "Examples: *0.90   *64   /64   +500", x + 30, y + 45,
                0xFF45C9FF, false);
    }

    private void drawMetric(GuiGraphicsExtractor g, int x, int y, int w, String label, String value) {
        g.fill(x, y, x + w, y + 82, 0xFF151F2B);
        g.fill(x, y, x + 3, y + 82, 0xFF45C9FF);
        g.text(font, label, x + 14, y + 15, 0xFF7F8EA3, false);
        g.text(font, value, x + 14, y + 41, 0xFFFFFFFF, true);
    }

    private void drawGrid(GuiGraphicsExtractor g) {
        for (int i = 0; i < width; i += 48) g.fill(i, 0, i + 1, height, 0x0A6FA0B8);
        for (int i = 0; i < height; i += 48) g.fill(0, i, width, i + 1, 0x0A6FA0B8);
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        int key = event.key();
        if (page == Page.CALCULATOR) {
            if (key == 259) { CalculatorState.backspace(); return true; }
            if (key == 257 || key == 335) { CalculatorState.evaluate(); return true; }
            if (key == 256) { onClose(); return true; }
        }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
