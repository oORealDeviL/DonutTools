# Donut Tools — Minecraft 26.1.2 / Fabric

First debug build.

## Features in this build

- Modern dark dashboard GUI
- Separate Calculator screen
- Separate Profit Tracker screen
- Separate keybinds:
  - Open Calculator (default O)
  - Open Profit Tracker (default P)
- Calculator supports mouse buttons and physical keyboard input
- Basic expression parser: +, -, *, /, parentheses, decimals
- Profit Tracker START / STOP / RESET
- Sale counter and session timer
- Generic sale-message parser for USD amounts
- A temporary `TEST +$1,000` button for debugging without joining DonutSMP

## Important limitation for the first test

The exact DonutSMP sale message has not been provided yet. The parser currently looks for a USD amount plus a sale-related word such as `sell`, `sold`, `sale`, `earned`, `revenue`, or `received`.

Once you provide the exact sale message, replace the generic parser with a strict DonutSMP parser. This avoids accidentally counting balance or unrelated currency messages.

## Build

Use Java 25 and run:

```text
./gradlew build
```

On Windows:

```text
gradlew.bat build
```

The built jar will be in:

```text
build/libs/
```

Put the produced jar into the Minecraft `mods` folder together with Fabric API 0.155.3+26.1.2.

## Debug flow

1. Launch Minecraft 26.1.2 with Fabric.
2. Open Controls and find the `Donut Tools` category.
3. Open Calculator with the assigned key.
4. Test keyboard input and mouse buttons.
5. Open Profit Tracker.
6. Press START.
7. Use `TEST +$1,000` to verify counters.
8. On DonutSMP, perform a real sale.
9. Check whether the real sale message is counted.
10. Send the exact sale message if it is not counted; the parser can then be made exact.

All user-facing mod text is English-only.
