package com.donuttools.client;

import java.text.NumberFormat;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ProfitTracker {
    private ProfitTracker() {}

    private static final Pattern MONEY = Pattern.compile(
            "(?i)(?:\\$|USD\\s*)[\\s]*([0-9][0-9,]*(?:\\.[0-9]+)?)"
    );

    private static final Pattern SALE_WORD = Pattern.compile(
            "(?i)\\b(sell|sold|sale|sales|sellaxe|earned|earn|revenue|received|receive|sold for)\\b"
    );

    private static boolean running;
    private static long totalCents;
    private static long lastSaleCents;
    private static long sales;
    private static long startedAt;
    private static final Deque<Long> history = new ArrayDeque<>();

    public static void start() {
        running = true;
        startedAt = System.currentTimeMillis();
    }

    public static void stop() {
        running = false;
    }

    public static void reset() {
        running = false;
        totalCents = 0;
        lastSaleCents = 0;
        sales = 0;
        startedAt = 0;
        history.clear();
    }

    public static boolean isRunning() {
        return running;
    }

    public static long getSales() {
        return sales;
    }

    public static long getTotalCents() {
        return totalCents;
    }

    public static long getLastSaleCents() {
        return lastSaleCents;
    }

    public static long getElapsedSeconds() {
        if (!running || startedAt == 0) return 0;
        return Math.max(0, (System.currentTimeMillis() - startedAt) / 1000L);
    }

    public static Deque<Long> history() {
        return new ArrayDeque<>(history);
    }

    public static boolean processMessage(String raw) {
        if (!running || raw == null || raw.isBlank()) return false;

        Matcher money = MONEY.matcher(raw);
        if (!money.find()) return false;

        // Avoid counting ordinary balance messages unless the line looks sale-related.
        if (!SALE_WORD.matcher(raw).find()) return false;

        String normalized = money.group(1).replace(",", "");
        try {
            double amount = Double.parseDouble(normalized);
            long cents = Math.round(amount * 100.0);
            if (cents <= 0) return false;
            recordSale(cents);
            return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    public static void recordSale(long cents) {
        if (cents <= 0) return;
        lastSaleCents = cents;
        totalCents += cents;
        sales++;
        history.addFirst(cents);
        while (history.size() > 12) history.removeLast();
    }

    public static String money(long cents) {
        double value = cents / 100.0;
        return NumberFormat.getNumberInstance(Locale.US).format(value) + " USD";
    }

    public static String compactMoney(long cents) {
        double value = cents / 100.0;
        if (Math.abs(value) >= 1_000_000_000) return String.format(Locale.US, "$%.2fB", value / 1_000_000_000);
        if (Math.abs(value) >= 1_000_000) return String.format(Locale.US, "$%.2fM", value / 1_000_000);
        if (Math.abs(value) >= 1_000) return String.format(Locale.US, "$%.2fK", value / 1_000);
        return String.format(Locale.US, "$%,.2f", value);
    }
}
