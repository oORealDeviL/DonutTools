package com.donuttools.client.gui;

import com.donuttools.client.DonutToolsClient;
import com.donuttools.client.ProfitTracker;
import com.donuttools.client.util.CalculatorState;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public final class DonutToolsScreen extends Screen {
    private enum Page { HOME, CALCULATOR, PROFIT }
    private final Screen parent;
    private Page page;

    private DonutToolsScreen(Screen parent, Page page) {
        super(Component.literal("Donut Tools"));
        this.parent = parent;
        this.page = page;
    }

    public static DonutToolsScreen calculator(Screen parent) {
        return new DonutToolsScreen(parent, Page.CALCULATOR);
    }

    public static DonutToolsScreen profit(Screen parent) {
        return new DonutToolsScreen(parent, Page.PROFIT);
    }

    public static DonutToolsScreen home(Screen parent) {
        return new DonutToolsScreen(parent, Page.HOME);
    }

    @Override
    protected void init() {
        clearWidgets();

        int panelW = Math.min(900, width - 80);
        int x = (width - panelW) / 2;
        int y = 82;

        if (page == Page.HOME) {
            addButton(x + 30, y + 50, panelW / 2 - 45, 54, "CALCULATOR", b -> {
                page = Page.CALCULATOR;
                rebuildWidgets();
            });
            addButton(x + panelW / 2 + 15, y + 50, panelW / 2 - 45, 54, "PROFIT TRACKER", b -> {
                page = Page.PROFIT;
                rebuildWidgets();
            });
        } else if (page == Page.CALCULATOR) {
            buildCalculator(x, y, panelW);
        } else {
            buildProfit(x, y, panelW);
        }

        addButton(x + 30, height - 56, 120, 28, "BACK", b -> {
            if (page == Page.HOME) onClose();
            else {
                page = Page.HOME;
                rebuildWidgets();
            }
        });
    }

    private void buildCalculator(int x, int y, int panelW) {
        String[][] keys = {
                {"7","8","9","÷"},
                {"4","5","6","×"},
                {"1","2","3","−"},
                {"0",".","(",")"},
                {"C","⌫","%","="}
        };
        int bw = 76, bh = 38, gap = 8;
        int startX = x + 45;
        int startY = y + 180;

        for (int r = 0; r < keys.length; r++) {
            for (int c = 0; c < keys[r].length; c++) {
                String key = keys[r][c];
                int bx = startX + c * (bw + gap);
                int by = startY + r * (bh + gap);
                addButton(bx, by, bw, bh, key, b -> calculatorKey(key));
            }
        }

        addButton(x + panelW - 205, startY + 190, 160, 38, "EVALUATE", b -> CalculatorState.evaluate());
        addButton(x + panelW - 205, startY + 236, 160, 38, "CLEAR", b -> CalculatorState.clear());
    }

    private void calculatorKey(String key) {
        switch (key) {
            case "C" -> CalculatorState.clear();
            case "⌫" -> CalculatorState.backspace();
            case "=" -> CalculatorState.evaluate();
            case "÷" -> CalculatorState.append("/");
            case "×" -> CalculatorState.append("*");
            case "−" -> CalculatorState.append("-");
            case "%" -> CalculatorState.append("/100");
            default -> CalculatorState.append(key);
        }
    }

    private void buildProfit(int x, int y, int panelW) {
        addButton(x + 45, y + 170, 145, 40, ProfitTracker.isRunning() ? "STOP" : "START", b -> {
            if (ProfitTracker.isRunning()) ProfitTracker.stop();
            else ProfitTracker.start();
            rebuildWidgets();
        });

        addButton(x + 205, y + 170, 145, 40, "RESET", b -> {
            ProfitTracker.reset();
            rebuildWidgets();
        });

        addButton(x + 365, y + 170, 175, 40, "TEST +$1,000", b -> {
            if (ProfitTracker.isRunning()) ProfitTracker.recordSale(100_000);
            rebuildWidgets();
        });
    }

    private void addButton(int x, int y, int w, int h, String label, Button.OnPress action) {
        addRenderableWidget(Button.builder(Component.literal(label), action).bounds(x, y, w, h).build());
    }

    @Override
    public void tick() {
        if (page == Page.PROFIT && ProfitTracker.isRunning()) {
            // Rebuild is intentionally avoided every tick; the screen redraws from live state.
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);

        // Background
        graphics.fill(0, 0, width, height, 0xFF070A10);
        drawBackdrop(graphics);

        int panelW = Math.min(900, width - 80);
        int x = (width - panelW) / 2;
        int y = 82;

        // Main card
        graphics.fill(x, y, x + panelW, height - 74, 0xFF101722);
        graphics.fill(x, y, x + panelW, y + 3, 0xFF55D6FF);

        graphics.text(font, "DONUT TOOLS", x + 30, 28, 0xFFFFFFFF, true);
        graphics.text(font, pageTitle(), x + 30, 52, 0xFF7F8EA3, false);

        if (page == Page.HOME) renderHome(graphics, x, y, panelW);
        if (page == Page.CALCULATOR) renderCalculator(graphics, x, y, panelW);
        if (page == Page.PROFIT) renderProfit(graphics, x, y, panelW);
    }

    private String pageTitle() {
        return switch (page) {
            case HOME -> "UTILITY DASHBOARD";
            case CALCULATOR -> "CALCULATOR";
            case PROFIT -> "PROFIT TRACKER";
        };
    }

    private void renderHome(GuiGraphicsExtractor g, int x, int y, int w) {
        g.text(font, "FAST TOOLS FOR YOUR DONUT WORKFLOW", x + 30, y + 25, 0xFFB9C7D8, false);
        drawCard(g, x + 30, y + 50, w / 2 - 45, 54, "CALCULATOR", "Math + item conversions");
        drawCard(g, x + w / 2 + 15, y + 50, w / 2 - 45, 54, "PROFIT TRACKER", "Track sale messages");
    }

    private void renderCalculator(GuiGraphicsExtractor g, int x, int y, int w) {
        drawCard(g, x + 35, y + 25, w - 70, 120, "EXPRESSION", CalculatorState.expression.isBlank() ? "0" : CalculatorState.expression);
        g.text(font, CalculatorState.result, x + w - 235, y + 92, 0xFF55D6FF, true);
        g.text(font, "Keyboard input is supported. Click buttons or type.", x + 45, y + 158, 0xFF7F8EA3, false);
        g.text(font, "DONUT CONVERTER", x + 45, y + 408, 0xFFFFFFFF, true);
        g.text(font, "Stacks / Shulkers / Double Chests are planned for the next debug pass.", x + 45, y + 428, 0xFF7F8EA3, false);
    }

    private void renderProfit(GuiGraphicsExtractor g, int x, int y, int w) {
        boolean running = ProfitTracker.isRunning();
        g.text(font, running ? "● RUNNING" : "● STOPPED", x + 45, y + 28, running ? 0xFF5CFF8A : 0xFFFF657A, true);

        drawMetric(g, x + 45, y + 65, 190, "SESSION TIME", formatTime(ProfitTracker.getElapsedSeconds()));
        drawMetric(g, x + 250, y + 65, 190, "SALES", String.valueOf(ProfitTracker.getSales()));
        drawMetric(g, x + 455, y + 65, w - 500, "LAST SALE", ProfitTracker.compactMoney(ProfitTracker.getLastSaleCents()));

        g.text(font, "TOTAL PROFIT", x + 45, y + 238, 0xFF7F8EA3, false);
        g.text(font, ProfitTracker.money(ProfitTracker.getTotalCents()), x + 45, y + 264, 0xFF55D6FF, true);

        g.text(font, "SALE HISTORY", x + 45, y + 320, 0xFFFFFFFF, true);
        int hy = y + 345;
        int index = ProfitTracker.getSales() > 0 ? (int) ProfitTracker.getSales() : 0;
        for (Long sale : ProfitTracker.history()) {
            g.text(font, "#" + index--, x + 45, hy, 0xFF6F7E91, false);
            g.text(font, ProfitTracker.money(sale), x + 105, hy, 0xFFDDE7F3, false);
            hy += 18;
            if (hy > height - 100) break;
        }
        g.text(font, "Auto-capture watches incoming server/chat messages for a sale keyword + USD amount.", x + 45, height - 96, 0xFF66758A, false);
    }

    private void drawMetric(GuiGraphicsExtractor g, int x, int y, int w, String label, String value) {
        g.fill(x, y, x + w, y + 84, 0xFF151F2C);
        g.fill(x, y, x + 2, y + 84, 0xFF2C9CC2);
        g.text(font, label, x + 14, y + 14, 0xFF7F8EA3, false);
        g.text(font, value, x + 14, y + 39, 0xFFFFFFFF, true);
    }

    private void drawCard(GuiGraphicsExtractor g, int x, int y, int w, int h, String title, String subtitle) {
        g.fill(x, y, x + w, y + h, 0xFF151F2C);
        g.fill(x, y, x + 3, y + h, 0xFF55D6FF);
        g.text(font, title, x + 16, y + 15, 0xFFFFFFFF, true);
        g.text(font, subtitle, x + 16, y + 34, 0xFF7F8EA3, false);
    }

    private void drawBackdrop(GuiGraphicsExtractor g) {
        // Subtle grid/lines for a technical dashboard feel.
        for (int i = 0; i < width; i += 40) g.fill(i, 0, i + 1, height, 0x0B6FA0B8);
        for (int i = 0; i < height; i += 40) g.fill(0, i, width, i + 1, 0x0B6FA0B8);
    }

    private static String formatTime(long totalSeconds) {
        long h = totalSeconds / 3600;
        long m = (totalSeconds % 3600) / 60;
        long s = totalSeconds % 60;
        return String.format("%02d:%02d:%02d", h, m, s);
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        int key = event.key();
        if (page == Page.CALCULATOR) {
            if (key == 259) { CalculatorState.backspace(); return true; } // Backspace
            if (key == 257 || key == 335) { CalculatorState.evaluate(); return true; } // Enter / numpad enter
            if (key == 256) { onClose(); return true; } // Escape
        }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
