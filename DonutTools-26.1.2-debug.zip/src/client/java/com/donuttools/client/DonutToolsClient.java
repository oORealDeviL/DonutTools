package com.donuttools.client;

import com.donuttools.DonutTools;
import com.donuttools.client.gui.DonutToolsScreen;
import com.donuttools.client.util.CalculatorState;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public final class DonutToolsClient implements ClientModInitializer {
    public static KeyMapping openCalculator;
    public static KeyMapping openProfitTracker;

    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath(DonutTools.MOD_ID, "main")
    );

    @Override
    public void onInitializeClient() {
        openCalculator = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.donuttools.open_calculator",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_O,
                CATEGORY
        ));

        openProfitTracker = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.donuttools.open_profit_tracker",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_P,
                CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openCalculator.consumeClick()) {
                if (client.screen == null) client.setScreen(DonutToolsScreen.calculator(null));
            }
            while (openProfitTracker.consumeClick()) {
                if (client.screen == null) client.setScreen(DonutToolsScreen.profit(null));
            }
        });

        ClientReceiveMessageEvents.GAME.register((message, overlay) ->
                ProfitTracker.processMessage(message.getString()));

        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) ->
                ProfitTracker.processMessage(message.getString()));

        DonutTools.LOGGER.info("Donut Tools client ready.");
    }

    public static void openCalculator() {
        Minecraft.getInstance().setScreen(DonutToolsScreen.calculator(Minecraft.getInstance().screen));
    }

    public static void openProfit() {
        Minecraft.getInstance().setScreen(DonutToolsScreen.profit(Minecraft.getInstance().screen));
    }

    public static void notify(String message) {
        if (Minecraft.getInstance().player != null) {
            Minecraft.getInstance().player.sendSystemMessage(Component.literal(message));
        }
    }
}
